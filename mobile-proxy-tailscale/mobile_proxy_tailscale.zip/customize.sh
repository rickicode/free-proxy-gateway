#!/system/bin/sh

print_title() {
  ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━"
  ui_print "  $1"
  ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━"
}

print_title "Mobile Proxy V3.1.0 (Multi-Port)"

if [ "$BOOTMODE" != true ]; then
  abort "! Install via KernelSU/Magisk Manager. Install dari recovery TIDAK didukung."
fi
if [ "$KSU" = true ] && [ "${KSU_VER_CODE:-99999}" -lt 10670 ]; then
  abort "! Update KernelSU / Manager dulu (butuh WebUI support)."
fi

TARGET_SB_VER="1.13.12"
TARGET_TS_VER="1.98.8"

# Direct download only — tanpa binary bawaan di ZIP.
# sing-box: build Android resmi SagerNet (NDK, linker /system/bin/linker64).
# JANGAN pakai raw file repo (itu x86-64 Linux, Exec format error di HP).
case "${ARCH:-arm64}" in
  arm64)
    SB_TGZ_NAME="sing-box-${TARGET_SB_VER}-android-arm64.tar.gz"
    DOWNLOAD_SB_URL="https://github.com/SagerNet/sing-box/releases/download/v${TARGET_SB_VER}/${SB_TGZ_NAME}"
    DOWNLOAD_TS_URL="https://github.com/anasfanani/tailscale-android-cli/releases/download/v${TARGET_TS_VER}-android/tailscale_${TARGET_TS_VER}_arm64.tgz"
    TS_TGZ_NAME="tailscale_${TARGET_TS_VER}_arm64.tgz"
    ;;
  arm)
    SB_TGZ_NAME="sing-box-${TARGET_SB_VER}-android-arm.tar.gz"
    DOWNLOAD_SB_URL="https://github.com/SagerNet/sing-box/releases/download/v${TARGET_SB_VER}/${SB_TGZ_NAME}"
    DOWNLOAD_TS_URL="https://github.com/anasfanani/tailscale-android-cli/releases/download/v${TARGET_TS_VER}-android/tailscale_${TARGET_TS_VER}_arm.tgz"
    TS_TGZ_NAME="tailscale_${TARGET_TS_VER}_arm.tgz"
    ;;
  x64|x86_64|x86)
    abort "! Emulator/x86 belum didukung (build hanya arm64)."
    ;;
  *)
    abort "! Arch tidak dikenal: ${ARCH:-?}"
    ;;
esac
DOWNLOAD_YACD_URL="https://github.com/MetaCubeX/Yacd-meta/archive/refs/heads/gh-pages.zip"

PERSIST_DIR="/data/adb/mobile_proxy_tailscale"
PERSIST_BIN="$PERSIST_DIR/bin"
BIN_DIR="$MODPATH/bin"
DASH_DIR="$MODPATH/dashboard"
mkdir -p "$BIN_DIR" "$PERSIST_BIN"
mkdir -p "$DASH_DIR"
mkdir -p "$PERSIST_DIR/run" "$PERSIST_DIR/logs" "$PERSIST_DIR/tmp"

# resolv.conf ala zax4r0 (DNS fallback)
touch "$PERSIST_DIR/tmp/resolv.conf" 2>/dev/null || true

dl() {
  _url="$1"; _out="$2"
  if command -v curl >/dev/null 2>&1; then
    curl -L --connect-timeout 20 -o "$_out" "$_url" 2>/dev/null && [ -s "$_out" ] && return 0
  fi
  if command -v wget >/dev/null 2>&1; then
    wget --no-check-certificate --timeout=60 -O "$_out" "$_url" 2>/dev/null && [ -s "$_out" ] && return 0
  fi
  return 1
}

# === Config & State Persisten ===
# Wajib 1 path SSOT: $PERSIST_DIR/config.json
# Template: config.json.example (TIDAK buat config.json otomatis).
OLD_MOD="/data/adb/modules/mobile_proxy_tailscale"

# 1. Salin template example ke PERSIST_DIR
cp -pf "$MODPATH/config.json.example" "$PERSIST_DIR/config.json.example" 2>/dev/null || true

# 2. Jika user sudah punya config.json di PERSIST_DIR atau pernah di OLD_MOD, pertahankan
if [ -f "$PERSIST_DIR/config.json" ]; then
  ui_print "[+] Menggunakan config.json aktif di $PERSIST_DIR"
elif [ -f "$OLD_MOD/config.json" ] && [ ! -L "$OLD_MOD/config.json" ]; then
  ui_print "[+] Migrasi config.json lama ke $PERSIST_DIR"
  cp -pf "$OLD_MOD/config.json" "$PERSIST_DIR/config.json" 2>/dev/null || true
else
  # Gak buat otomatis! Hanya sediakan config.json.example
  ui_print "[!] config.json belum ada di $PERSIST_DIR"
  ui_print "[i] Salin manual: cp $PERSIST_DIR/config.json.example $PERSIST_DIR/config.json"
  ui_print "[i] lalu isi authkey Tailscale kamu."
fi

# Pastikan di MODPATH TIDAK ADA config.json (wajib 1 path, tidak ada duplikat/symlink)
rm -f "$MODPATH/config.json" 2>/dev/null || true

for _f in tailscaled.state live-proxies.json mobile-proxy-singbox.json; do
  if [ ! -f "$PERSIST_DIR/$_f" ]; then
    for _src in "$OLD_MOD/state/$_f" "$OLD_MOD/$_f"; do
      if [ -f "$_src" ]; then
        ui_print "[+] Preserving $_f"
        cp -pf "$_src" "$PERSIST_DIR/$_f"
        break
      fi
    done
  fi
done

# Inisialisasi awal mobile-proxy-singbox.json dari bundle (offline ready 120 proxy)
if [ ! -f "$PERSIST_DIR/mobile-proxy-singbox.json" ] && [ -f "$MODPATH/mobile-proxy-singbox.json" ]; then
  ui_print "[+] Inisialisasi offline mobile-proxy-singbox.json (120 proxy pool)"
  cp -pf "$MODPATH/mobile-proxy-singbox.json" "$PERSIST_DIR/mobile-proxy-singbox.json" 2>/dev/null || true
fi

# === Binary & Assets (Cache-First di PERSIST, download hanya jika belum ada) ===
# 1) sing-box (tar.gz resmi SagerNet Android NDK build)
if [ -f "$PERSIST_BIN/sing-box" ] && "$PERSIST_BIN/sing-box" version >/dev/null 2>&1; then
  ui_print "[+] Reuse cached sing-box dari $PERSIST_BIN"
  cp -pf "$PERSIST_BIN/sing-box" "$BIN_DIR/sing-box"
  chmod 755 "$BIN_DIR/sing-box" 2>/dev/null || true
elif [ -f "$OLD_MOD/bin/sing-box" ] && "$OLD_MOD/bin/sing-box" version >/dev/null 2>&1; then
  ui_print "[+] Reuse sing-box dari instalasi lama"
  cp -pf "$OLD_MOD/bin/sing-box" "$BIN_DIR/sing-box"
  cp -pf "$OLD_MOD/bin/sing-box" "$PERSIST_BIN/sing-box" 2>/dev/null || true
  chmod 755 "$BIN_DIR/sing-box" 2>/dev/null || true
else
  ui_print "[*] Downloading sing-box v$TARGET_SB_VER ($SB_TGZ_NAME)..."
  _SB_TAR="$PERSIST_DIR/tmp/$SB_TGZ_NAME"
  rm -f "$BIN_DIR/sing-box" 2>/dev/null || true
  if dl "$DOWNLOAD_SB_URL" "$_SB_TAR"; then
    _sz=$(stat -c%s "$_SB_TAR" 2>/dev/null || wc -c < "$_SB_TAR" 2>/dev/null || echo 0)
    if [ "$_sz" -lt 5242880 ]; then
      ui_print "[!] sing-box tgz invalid (size $_sz < 5MB, mungkin 404 HTML)"
      rm -f "$_SB_TAR" 2>/dev/null || true
    elif tar -tzf "$_SB_TAR" 2>/dev/null | grep -q "sing-box$"; then
      _SB_TMP="${TMPDIR:-/tmp}/mproxy_sb"
      rm -rf "$_SB_TMP"; mkdir -p "$_SB_TMP"
      if tar -xzf "$_SB_TAR" -C "$_SB_TMP" 2>/dev/null; then
        _found=$(find "$_SB_TMP" -type f -name "sing-box" 2>/dev/null | head -n 1)
        if [ -n "$_found" ] && [ -s "$_found" ]; then
          cp -pf "$_found" "$BIN_DIR/sing-box" 2>/dev/null || true
          chmod 755 "$BIN_DIR/sing-box" 2>/dev/null || true
          if "$BIN_DIR/sing-box" version >/dev/null 2>&1; then
            # Simpan ke cache persisten agar install/update berikutnya tidak unduh ulang
            cp -pf "$BIN_DIR/sing-box" "$PERSIST_BIN/sing-box" 2>/dev/null || true
            ui_print "[+] sing-box v$TARGET_SB_VER verified & cached ($((_sz/1048576))MB tgz)"
          else
            ui_print "[-] sing-box binary test failed (Exec format? cek ARCH=${ARCH:-?})"
            rm -f "$BIN_DIR/sing-box" 2>/dev/null || true
          fi
        else
          ui_print "[-] sing-box tidak ketemu di dalam tgz"
        fi
      else
        ui_print "[-] Gagal ekstrak $SB_TGZ_NAME"
      fi
      rm -rf "$_SB_TMP" 2>/dev/null || true
    else
      ui_print "[-] tgz bukan arsip sing-box valid"
      rm -f "$_SB_TAR" 2>/dev/null || true
    fi
    rm -f "$_SB_TAR" 2>/dev/null || true
  else
    ui_print "[-] Download sing-box gagal (cek koneksi)"
  fi
fi
if [ ! -f "$BIN_DIR/sing-box" ]; then
  abort "! Gagal download sing-box dan tidak ada cache lokal."
fi

# 2) tailscaled (tar.gz release anasfanani)
if [ -f "$PERSIST_BIN/tailscaled" ]; then
  ui_print "[+] Reuse cached tailscaled dari $PERSIST_BIN"
  cp -pf "$PERSIST_BIN/tailscaled" "$BIN_DIR/tailscaled"
elif [ -f "$OLD_MOD/bin/tailscaled" ]; then
  ui_print "[+] Reuse tailscaled dari instalasi lama"
  cp -pf "$OLD_MOD/bin/tailscaled" "$BIN_DIR/tailscaled"
  cp -pf "$OLD_MOD/bin/tailscaled" "$PERSIST_BIN/tailscaled" 2>/dev/null || true
else
  ui_print "[*] Downloading tailscaled ($TS_TGZ_NAME)..."
  _TS_TAR="$PERSIST_DIR/tmp/$TS_TGZ_NAME"
  if dl "$DOWNLOAD_TS_URL" "$_TS_TAR"; then
    if tar -xzf "$_TS_TAR" -C "$BIN_DIR/" 2>/dev/null; then
      if [ ! -f "$BIN_DIR/tailscaled" ]; then
        _found=$(find "$BIN_DIR" -type f -name "tailscaled" 2>/dev/null | head -n 1)
        [ -n "$_found" ] && mv -f "$_found" "$BIN_DIR/tailscaled"
      fi
      cp -pf "$BIN_DIR/tailscaled" "$PERSIST_BIN/tailscaled" 2>/dev/null || true
      ui_print "[+] tailscaled verified & cached"
    else
      abort "! Gagal ekstrak $TS_TGZ_NAME"
    fi
  else
    abort "! Gagal download tailscaled dan tidak ada cache lokal."
  fi
  rm -f "$_TS_TAR" 2>/dev/null || true
fi

ln -sf "$BIN_DIR/tailscaled" "$BIN_DIR/tailscale"

# 3) Yacd Dashboard (offline fallback)
_TMPD="${TMPDIR:-/tmp}/mproxy_yacd"
if [ -f "$PERSIST_DIR/yacd_cache.zip" ]; then
  ui_print "[+] Reuse cached Yacd dari $PERSIST_DIR"
  rm -rf "$_TMPD"; mkdir -p "$_TMPD"
  unzip -q "$PERSIST_DIR/yacd_cache.zip" -d "$_TMPD" 2>/dev/null || true
  cp -rf "$_TMPD/Yacd-meta-gh-pages/"* "$DASH_DIR/" 2>/dev/null || cp -rf "$_TMPD/"* "$DASH_DIR/" 2>/dev/null || true
  rm -rf "$_TMPD" 2>/dev/null || true
elif [ -d "$OLD_MOD/dashboard" ] && [ -f "$OLD_MOD/dashboard/index.html" ]; then
  ui_print "[+] Reuse Yacd dari instalasi lama"
  cp -rf "$OLD_MOD/dashboard/"* "$DASH_DIR/" 2>/dev/null || true
else
  ui_print "[*] Downloading Yacd-meta Web Dashboard..."
  rm -rf "$_TMPD"; mkdir -p "$_TMPD"
  if dl "$DOWNLOAD_YACD_URL" "$_TMPD/yacd.zip"; then
    if unzip -q "$_TMPD/yacd.zip" -d "$_TMPD" 2>/dev/null; then
      if [ -d "$_TMPD/Yacd-meta-gh-pages" ]; then
        cp -rf "$_TMPD/Yacd-meta-gh-pages/"* "$DASH_DIR/"
      else
        cp -rf "$_TMPD/"* "$DASH_DIR/" 2>/dev/null || true
      fi
      cp -pf "$_TMPD/yacd.zip" "$PERSIST_DIR/yacd_cache.zip" 2>/dev/null || true
      ui_print "[+] Yacd Dashboard terinstall & cached ($DASH_DIR)"
    fi
    rm -rf "$_TMPD" 2>/dev/null || true
  else
    ui_print "[-] Yacd gagal download, lanjut dengan fallback public URL."
  fi
fi

# === FIX #4: Permission & Ownership ===
if command -v set_perm_recursive >/dev/null 2>&1; then
  set_perm_recursive "$BIN_DIR/" 0 3005 0755 0755 "u:object_r:system_file:s0"
else
  chown -R root:net_admin "$BIN_DIR" 2>/dev/null || chown -R 0:3005 "$BIN_DIR" 2>/dev/null || true
  chmod -R 755 "$BIN_DIR" 2>/dev/null || true
fi
chmod 755 "$MODPATH/service.sh" "$MODPATH/action.sh" 2>/dev/null || true
chmod 755 "$MODPATH/scripts/"*.py "$MODPATH/scripts/"*.inotify 2>/dev/null || true
# dashboard readable agar sing-box external_ui tidak 404 (Yacd 出错了 fix)
chmod 755 "$DASH_DIR" 2>/dev/null || true
chmod 644 "$DASH_DIR/index.html" 2>/dev/null || true

ui_print "[+] Setup binaries & assets complete."
ui_print "[i] Config Path (wajib 1): $PERSIST_DIR/config.json"
ui_print "[i] Template Example     : $PERSIST_DIR/config.json.example"
ui_print "[i] State persisten      : $PERSIST_DIR (tailscaled.state, mobile-proxy-singbox.json)"
ui_print "[i] Binary cache   : $PERSIST_BIN (bisa flash offline kelak)"
ui_print "[i] WebUI KernelSU : webroot/index.html (bridge ksu global)"
ui_print "[i] Yacd lokal     : dashboard/ (disserve sing-box di 0.0.0.0:9090/ui/)"
