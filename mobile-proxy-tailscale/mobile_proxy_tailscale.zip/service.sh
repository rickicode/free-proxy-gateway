#!/system/bin/sh
MODDIR=${0%/*}
PERSIST_DIR="/data/adb/mobile_proxy_tailscale"

BIN_DIR="$MODDIR/bin"
# Wajib 1 path: fisik hanya di PERSIST_DIR. Gak ada duplikat di MODDIR.
CONF_FILE="$PERSIST_DIR/config.json"
RUN_DIR="$PERSIST_DIR/run"
LOG_DIR="$PERSIST_DIR/logs"
PID_DIR="$PERSIST_DIR/run"

# single-instance guard: bunuh service.sh lama biar tidak ada loop ganda
# (action.sh start / inotify enable bisa spawn service.sh baru)
for _p in $(pidof sh 2>/dev/null); do
  if [ "$_p" != "$$" ] && grep -q "mobile_proxy_tailscale/service.sh" "/proc/$_p/cmdline" 2>/dev/null; then
    kill -9 "$_p" 2>/dev/null || true
  fi
done

mkdir -p "$PERSIST_DIR/run" "$PERSIST_DIR/logs"

# --- Migrasi state lama dari dalam MODDIR (update dari v3.0.0) ---
# Wajib 1 path: fisik hanya di $PERSIST_DIR/config.json. Tidak ada duplikat/symlink di MODDIR.
if [ -d "$MODDIR/state" ] && [ ! -L "$MODDIR/state" ]; then
  for f in tailscaled.state live-proxies.json config.json; do
    if [ -f "$MODDIR/state/$f" ] && [ ! -f "$PERSIST_DIR/$f" ]; then
      mv -f "$MODDIR/state/$f" "$PERSIST_DIR/$f" 2>/dev/null || cp -pf "$MODDIR/state/$f" "$PERSIST_DIR/$f" 2>/dev/null || true
    fi
  done
fi
# Bersihkan config.json duplikat di MODDIR (wajib 1 path, SSOT di PERSIST_DIR)
rm -f "$MODDIR/config.json" "$MODDIR/config.json.example" "$MODDIR/state/config.json" 2>/dev/null || true

# Compat symlink agar path lama ($MODDIR/run, $MODDIR/logs) tetap jalan
for d in run logs; do
  if [ ! -L "$MODDIR/$d" ]; then
    rm -rf "$MODDIR/$d" 2>/dev/null
    ln -sfn "$PERSIST_DIR/$d" "$MODDIR/$d" 2>/dev/null || mkdir -p "$MODDIR/$d"
  fi
done

# Boot baru = hapus flag .stopped sisa sesi sebelumnya (biar daemon start normal)
rm -f "$PERSIST_DIR/.stopped" 2>/dev/null || true

# === FIX #1: Boot tunggu lengkap (pola taamarin/box) ===
# taamarin tunggu bootanim=stopped, zax4r0 tunggu packages.xml. Kita gabung.
wait_for_boot() {
  until [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ]; do sleep 2; done
  # bootanim (jika ada)
  for _i in 1 2 3 4 5 6; do
    _b=$(getprop init.svc.bootanim 2>/dev/null)
    if [ "$_b" = "stopped" ] || [ -z "$_b" ]; then break; fi
    sleep 2
  done
  # tunggu package manager siap (pola taamarin refresh_box)
  _c=0
  while [ ! -f "/data/system/packages.xml" ] && [ $_c -lt 30 ]; do sleep 1; _c=$((_c+1)); done
  sleep 5
}
wait_for_boot

# ulimit untuk 60+ outbound (per outbound buka socket healthcheck)
ulimit -n 4096 2>/dev/null || true

export PATH="$MODDIR/bin:$PATH"
export HOME="$PERSIST_DIR"

chmod 755 "$MODDIR/scripts/"*.inotify 2>/dev/null || true

# === FIX #4: ownership root:net_admin (pola taamarin box_ownership + zax4r0 chown root:net_bt_admin) ===
setup_ownership() {
  # Android net_admin = 3005, net_bt_admin = 3002
  if [ -f "$BIN_DIR/tailscaled" ]; then
    chown root:net_admin "$BIN_DIR/tailscaled" 2>/dev/null || chown 0:3005 "$BIN_DIR/tailscaled" 2>/dev/null || chown root:root "$BIN_DIR/tailscaled" 2>/dev/null || true
    chown root:net_admin "$BIN_DIR/sing-box" 2>/dev/null || chown 0:3005 "$BIN_DIR/sing-box" 2>/dev/null || true
    chmod 0755 "$BIN_DIR/tailscaled" "$BIN_DIR/sing-box" 2>/dev/null || true
  fi
  # resolv.conf ala zax4r0 postinstall (fix DNS userspace)
  mkdir -p "$PERSIST_DIR/tmp" 2>/dev/null || true
  [ -f "$PERSIST_DIR/tmp/resolv.conf" ] || touch "$PERSIST_DIR/tmp/resolv.conf" 2>/dev/null || true
}
setup_ownership

is_running() {
  if command -v pgrep >/dev/null 2>&1; then
    pgrep -f "$1" >/dev/null 2>&1
  else
    ps 2>/dev/null | grep -q "$1"
  fi
}

kill_pat() {
  if command -v pkill >/dev/null 2>&1; then
    pkill -f "$1" 2>/dev/null || true
  else
    for p in $(ps -o pid,args 2>/dev/null | grep "$1" | grep -v grep | awk '{print $1}'); do
      kill -9 "$p" 2>/dev/null
    done
  fi
}

# === FIX #2: rotasi log (pola taamarin box.service box_check_logs) ===
rotate_logs() {
  # bak untuk log besar >10MB
  for _lf in "$LOG_DIR/tailscaled.log" "$LOG_DIR/singbox.log" "$LOG_DIR/singbox_run.log"; do
    if [ -f "$_lf" ]; then
      _sz=$(stat -c%s "$_lf" 2>/dev/null || wc -c < "$_lf" 2>/dev/null || echo 0)
      if [ "$_sz" -gt 10485760 ]; then
        mv -f "$_lf" "$_lf.bak" 2>/dev/null || true
        touch "$_lf" 2>/dev/null || true
      fi
    fi
  done
  # hapus log/bak >1 hari (pola taamarin: find mtime +1)
  find "$LOG_DIR" -maxdepth 1 -type f \( -name "*.log.bak" -o -name "*.bak" \) -mtime +1 -exec rm -f {} \; 2>/dev/null || true
  find "$LOG_DIR" -maxdepth 1 -type f -name "*.log" -mtime +7 -exec rm -f {} \; 2>/dev/null || true
}
rotate_logs

# === FIX #3: validasi JSON sebelum run (pola taamarin sh -n settings.ini) ===
validate_json() {
  _f="$1"
  if command -v python3 >/dev/null 2>&1; then
    python3 -m json.tool "$_f" >/dev/null 2>&1 && return 0
    return 1
  elif command -v jq >/dev/null 2>&1; then
    jq empty "$_f" >/dev/null 2>&1 && return 0
    return 1
  else
    # fallback: cek ada tag penting
    grep -q '"inbounds"' "$_f" 2>/dev/null && return 0
    return 1
  fi
}

# Ambil Config — WAJIB 1 path di $CONF_FILE ($PERSIST_DIR/config.json)
AUTHKEY=""
HOSTNAME="mobile-proxy-hp"
PORT="1080"

if [ -f "$CONF_FILE" ]; then
  AUTHKEY=$(grep -o '"authkey": *"[^"]*"' "$CONF_FILE" 2>/dev/null | head -n 1 | cut -d'"' -f4)
  _h=$(grep -o '"hostname": *"[^"]*"' "$CONF_FILE" 2>/dev/null | head -n 1 | cut -d'"' -f4)
  _p=$(grep -o '"port": *[0-9]*' "$CONF_FILE" 2>/dev/null | head -n 1 | grep -o '[0-9]*')
  [ -n "$_h" ] && HOSTNAME="$_h"
  [ -n "$_p" ] && PORT="$_p"
else
  echo "$(date): $CONF_FILE belum ada. Silakan salin dari config.json.example dan isi authkey." >> "$LOG_DIR/tailscale_up.log"
fi

kill_pat "$BIN_DIR/tailscaled"
kill_pat "$BIN_DIR/sing-box"
sleep 1

# Daemon Loop Tailscaled
tailscaled_loop() {
  while true; do
    # respawn guard: jangan hidupkan lagi kalau user pencet Stop di WebUI/action.sh
    if [ -f "$PERSIST_DIR/.stopped" ]; then
      sleep 10
      continue
    fi
    if ! is_running "$BIN_DIR/tailscaled"; then
      # rotasi sebelum start baru (pola anasfanani: mv log bak)
      [ -f "$LOG_DIR/tailscaled.log" ] && mv -f "$LOG_DIR/tailscaled.log" "$LOG_DIR/tailscaled.log.bak" 2>/dev/null || true
      "$BIN_DIR/tailscaled" \
        --tun=userspace-networking \
        --state="$PERSIST_DIR/tailscaled.state" \
        --socket="$RUN_DIR/tailscaled.sock" \
        --port=41641 \
        --verbose=1 >> "$LOG_DIR/tailscaled.log" 2>&1 &
      TSD_PID=$!
      echo "$TSD_PID" > "$PID_DIR/tailscaled.pid" 2>/dev/null || true
      echo -1000 > /proc/$TSD_PID/oom_score_adj 2>/dev/null || true
    fi
    sleep 10
  done
}

# Daemon Loop Sing-box (Multi-port + Clash API + Yacd lokal)
singbox_loop() {
  while true; do
    # respawn guard: jangan hidupkan lagi kalau user pencet Stop di WebUI/action.sh
    if [ -f "$PERSIST_DIR/.stopped" ]; then
      sleep 10
      continue
    fi
    if ! is_running "$BIN_DIR/sing-box"; then
      cat <<EOF > "$RUN_DIR/singbox_proxy.json"
{
  "log": {
    "level": "info",
    "output": "$LOG_DIR/singbox.log",
    "timestamp": true
  },
  "dns": {
    "servers": [
      {
        "type": "udp",
        "tag": "dns-direct",
        "server": "1.1.1.1"
      },
      {
        "type": "udp",
        "tag": "dns-direct2",
        "server": "8.8.8.8"
      }
    ],
    "strategy": "prefer_ipv4"
  },
  "experimental": {
    "clash_api": {
      "external_controller": "0.0.0.0:9090",
      "external_ui": "$MODDIR/dashboard",
      "secret": "singbox",
      "default_mode": "rule"
    }
  },
  "inbounds": [
    {
      "type": "http",
      "tag": "proxy-1080",
      "listen": "0.0.0.0",
      "listen_port": $PORT,
      "domain_resolver": "dns-direct"
    },
    {
      "type": "mixed",
      "tag": "mixed-1011",
      "listen": "0.0.0.0",
      "listen_port": 1011,
      "domain_resolver": "dns-direct"
    },
    {
      "type": "mixed",
      "tag": "mixed-1012",
      "listen": "0.0.0.0",
      "listen_port": 1012,
      "domain_resolver": "dns-direct"
    },
    {
      "type": "mixed",
      "tag": "mixed-1013",
      "listen": "0.0.0.0",
      "listen_port": 1013,
      "domain_resolver": "dns-direct"
    },
    {
      "type": "mixed",
      "tag": "mixed-1014",
      "listen": "0.0.0.0",
      "listen_port": 1014,
      "domain_resolver": "dns-direct"
    }
  ],
  "outbounds": [
    {
      "type": "direct",
      "tag": "DIRECT",
      "domain_resolver": "dns-direct"
    }
  ],
  "route": {
    "rules": [
      {
        "inbound": [
          "proxy-1080"
        ],
        "outbound": "DIRECT"
      },
      {
        "inbound": [
          "mixed-1011"
        ],
        "outbound": "PROXY-FREE"
      },
      {
        "inbound": [
          "mixed-1012"
        ],
        "outbound": "PROXY-AMERICA"
      },
      {
        "inbound": [
          "mixed-1013"
        ],
        "outbound": "PROXY-ASIA"
      },
      {
        "inbound": [
          "mixed-1014"
        ],
        "outbound": "PROXY-EUROPE"
      }
    ],
    "auto_detect_interface": false
  }
}
EOF

      # Zero-Python inject: pakai mobile-proxy-singbox.json (50KB siap pakai dari CI)
      # Jika file ada & valid JSON → pakai langsung. Jika corrupt/kosong → fallback DIRECT.
      _SRC="$PERSIST_DIR/mobile-proxy-singbox.json"
      _DST="$RUN_DIR/singbox_proxy.json"
      # migrasi legasy: jika hanya live-proxies.json lama ada, biarkan fetch yg konversi
      if [ -f "$_SRC" ] && validate_json "$_SRC" 2>/dev/null && grep -q '"PROXY-FREE"' "$_SRC" 2>/dev/null; then
        cp -f "$_SRC" "$_DST" 2>/dev/null || cat "$_SRC" > "$_DST"
        # Patch dinamis: PORT (user ganti 1080), external_ui, log output — pakai jq jika ada, else sed
        if command -v jq >/dev/null 2>&1; then
          _tmp2="$_DST.tmp"
          jq --arg log "$LOG_DIR/singbox.log" --arg dash "$MODDIR/dashboard" --argjson port "$PORT" \
            '.log.output=$log | .experimental.clash_api.external_ui=$dash | (.inbounds[] | select(.tag=="proxy-1080") | .listen_port)=$port' \
            "$_DST" > "$_tmp2" 2>/dev/null && mv -f "$_tmp2" "$_DST" 2>/dev/null || true
        else
          # fallback busybox sed — cukup untuk 3 field
          sed -i "s|\"output\": *\"[^\"]*\"|\"output\": \"$LOG_DIR/singbox.log\"|; s|\"external_ui\": *\"[^\"]*\"|\"external_ui\": \"$MODDIR/dashboard\"|; s|\"listen_port\": *1080|\"listen_port\": $PORT|" "$_DST" 2>/dev/null || true
        fi
        echo "$(date): inject OK via mobile-proxy-singbox.json ($(grep -c '"tag"' "$_DST" 2>/dev/null || echo ?) outbounds)" >> "$LOG_DIR/singbox_run.log" 2>&1
      else
        if [ -f "$_SRC" ]; then
          echo "$(date): inject FAILED (mobile-proxy-singbox.json invalid/no PROXY-FREE) — fallback DIRECT" >> "$LOG_DIR/singbox_run.log" 2>&1
        else
          echo "$(date): inject SKIP (no mobile-proxy-singbox.json yet, fetch akan download) — fallback DIRECT" >> "$LOG_DIR/singbox_run.log" 2>&1
        fi
        # _DST sudah berisi template DIRECT+PROXY refs dari heredoc di atas → ubah semua ke DIRECT agar valid
        sed -i 's/"PROXY-FREE"/"DIRECT"/g; s/"PROXY-AMERICA"/"DIRECT"/g; s/"PROXY-ASIA"/"DIRECT"/g; s/"PROXY-EUROPE"/"DIRECT"/g; s/"GLOBAL"/"DIRECT"/g' "$_DST" 2>/dev/null || true
      fi

      # FIX #3: validasi JSON sebelum run
      if ! validate_json "$RUN_DIR/singbox_proxy.json"; then
        echo "$(date): sing-box config invalid, fallback ke DIRECT" >> "$LOG_DIR/singbox_run.log" 2>&1
        cat <<FBEOF > "$RUN_DIR/singbox_proxy.json"
{"log":{"level":"info","output":"$LOG_DIR/singbox.log"},"dns":{"servers":[{"type":"udp","tag":"dns-direct","server":"1.1.1.1"}],"strategy":"prefer_ipv4"},"inbounds":[{"type":"http","tag":"proxy-1080","listen":"0.0.0.0","listen_port":$PORT,"domain_resolver":"dns-direct"},{"type":"mixed","tag":"mixed-1011","listen":"0.0.0.0","listen_port":1011,"domain_resolver":"dns-direct"},{"type":"mixed","tag":"mixed-1012","listen":"0.0.0.0","listen_port":1012,"domain_resolver":"dns-direct"},{"type":"mixed","tag":"mixed-1013","listen":"0.0.0.0","listen_port":1013,"domain_resolver":"dns-direct"},{"type":"mixed","tag":"mixed-1014","listen":"0.0.0.0","listen_port":1014,"domain_resolver":"dns-direct"}],"outbounds":[{"type":"direct","tag":"DIRECT","domain_resolver":"dns-direct"}],"route":{"rules":[{"inbound":["proxy-1080"],"outbound":"DIRECT"},{"inbound":["mixed-1011"],"outbound":"DIRECT"},{"inbound":["mixed-1012"],"outbound":"DIRECT"},{"inbound":["mixed-1013"],"outbound":"DIRECT"},{"inbound":["mixed-1014"],"outbound":"DIRECT"}],"auto_detect_interface":false}}
FBEOF
      fi

      # optional cek bin executable (pola taamarin box_check_bin)
      if [ ! -x "$BIN_DIR/sing-box" ]; then
        echo "$(date): sing-box not executable, skip start" >> "$LOG_DIR/singbox_run.log" 2>&1
        sleep 10
        continue
      fi

      [ -f "$LOG_DIR/singbox_run.log" ] && mv -f "$LOG_DIR/singbox_run.log" "$LOG_DIR/singbox_run.log.bak" 2>/dev/null || true
      "$BIN_DIR/sing-box" run -c "$RUN_DIR/singbox_proxy.json" >> "$LOG_DIR/singbox_run.log" 2>&1 &
      SB_PID=$!
      echo "$SB_PID" > "$PID_DIR/sing-box.pid" 2>/dev/null || true
      echo -1000 > /proc/$SB_PID/oom_score_adj 2>/dev/null || true
      # validasi pid hidup (pola taamarin kill -0)
      sleep 3
      if ! kill -0 "$SB_PID" 2>/dev/null; then
        echo "$(date): sing-box failed to start, cek singbox_run.log" >> "$LOG_DIR/singbox_run.log" 2>&1
      fi
    fi
    sleep 10
  done
}

# Fetch proxy pool (cache di PERSIST agar survive update)
# Zero-Python: download mobile-proxy-singbox.json (50KB siap pakai dari CI)
# Multi-mirror fallback: raw GitHub + jsdelivr + gh-proxy (anti-blokir ISP Indonesia)
fetch_proxies() {
  _tmp="$PERSIST_DIR/mobile-proxy-singbox_tmp.json"
  _dst="$PERSIST_DIR/mobile-proxy-singbox.json"
  rm -f "$_tmp" 2>/dev/null || true
  _URLS="https://raw.githubusercontent.com/rickicode/free-proxy-singbox/main/output/mobile-proxy-singbox.json https://cdn.jsdelivr.net/gh/rickicode/free-proxy-singbox@main/output/mobile-proxy-singbox.json https://gh-proxy.com/https://raw.githubusercontent.com/rickicode/free-proxy-singbox/main/output/mobile-proxy-singbox.json"
  _OK=0
  for _u in $_URLS; do
    [ -z "$_u" ] && continue
    if command -v curl >/dev/null 2>&1; then
      curl -sL --connect-timeout 15 --max-time 30 "$_u" -o "$_tmp" 2>/dev/null || true
    elif command -v wget >/dev/null 2>&1; then
      wget -q --timeout=30 -O "$_tmp" "$_u" 2>/dev/null || true
    fi
    # Validasi: file harus >10KB dan ada PROXY-FREE + outbounds (bukan HTML 404/ratelimit)
    if [ -s "$_tmp" ]; then
      _sz=$(stat -c%s "$_tmp" 2>/dev/null || wc -c < "$_tmp" 2>/dev/null || echo 0)
      if [ "$_sz" -gt 10240 ] && grep -q '"PROXY-FREE"' "$_tmp" 2>/dev/null && grep -q '"outbounds"' "$_tmp" 2>/dev/null; then
        _OK=1
        echo "$(date): fetch success from $_u (${_sz}B)" >> "$LOG_DIR/singbox_run.log" 2>&1
        break
      fi
    fi
    rm -f "$_tmp" 2>/dev/null || true
  done

  if [ "$_OK" = "1" ] && [ -s "$_tmp" ]; then
    # hash compare: jangan restart sing-box kalau konten sama
    if [ -f "$_dst" ] && command -v sha1sum >/dev/null 2>&1; then
      _h_old=$(sha1sum "$_dst" 2>/dev/null | awk '{print $1}')
      _h_new=$(sha1sum "$_tmp" 2>/dev/null | awk '{print $1}')
      if [ "$_h_old" = "$_h_new" ]; then
        rm -f "$_tmp" 2>/dev/null || true
        return 0
      fi
    fi
    mv -f "$_tmp" "$_dst"
    kill_pat "$BIN_DIR/sing-box"
  else
    rm -f "$_tmp" 2>/dev/null || true
    echo "$(date): fetch FAILED across all 3 mirrors" >> "$LOG_DIR/singbox_run.log" 2>&1
  fi
}

# Watcher: toggle disable tanpa reboot + restart saat network berubah (pola anasfanani/box4)
start_watchers() {
  command -v inotifyd >/dev/null 2>&1 || return 0
  if command -v pidof >/dev/null 2>&1; then
    for p in $(pidof inotifyd 2>/dev/null); do
      if grep -q "mproxy.inotify" "/proc/$p/cmdline" 2>/dev/null; then
        kill -9 "$p" 2>/dev/null || true
      fi
      if grep -q "mproxy-net.inotify" "/proc/$p/cmdline" 2>/dev/null; then
        kill -9 "$p" 2>/dev/null || true
      fi
    done
  fi
  inotifyd "$MODDIR/scripts/mproxy.inotify" "$MODDIR" >/dev/null 2>&1 &
  if [ -d /data/misc/net ]; then
    inotifyd "$MODDIR/scripts/mproxy-net.inotify" "/data/misc/net" >/dev/null 2>&1 &
  fi
}

# Jalankan daemon loops di background
tailscaled_loop &
sleep 3

# Login sekali jika authkey valid
if [ -n "$AUTHKEY" ] && [ "$AUTHKEY" != "tskey-auth-xxxx" ]; then
  # tunggu socket siap dulu
  for _w in 1 2 3 4 5; do [ -S "$RUN_DIR/tailscaled.sock" ] && break; sleep 2; done

  # Auto-recovery: jika node state corrupt / OS mismatch (misal ganti binary linux -> android)
  _st=$("$BIN_DIR/tailscale" --socket="$RUN_DIR/tailscaled.sock" status 2>&1)
  if echo "$_st" | grep -qi "node OS changed"; then
    echo "$(date): Tailscale node OS conflict terdeteksi. Resetting state..." >> "$LOG_DIR/tailscale_up.log"
    "$BIN_DIR/tailscale" --socket="$RUN_DIR/tailscaled.sock" logout >/dev/null 2>&1 || true
    rm -f "$PERSIST_DIR/tailscaled.state" 2>/dev/null || true
    kill_pat "$BIN_DIR/tailscaled"
    sleep 3
    # loop tailscaled akan otomatis respawn dengan state baru
    sleep 2
  fi

  "$BIN_DIR/tailscale" --socket="$RUN_DIR/tailscaled.sock" up \
    --reset \
    --authkey="$AUTHKEY" \
    --hostname="$HOSTNAME" \
    --accept-dns=false \
    --accept-routes=true >> "$LOG_DIR/tailscale_up.log" 2>&1 &
fi

# Fetch proxy pertama kali (foreground jika cache belum ada agar config awal langsung berisi proxy)
if [ ! -f "$PERSIST_DIR/mobile-proxy-singbox.json" ]; then
  fetch_proxies
else
  # Background update jika sudah ada cache lokal
  fetch_proxies &
fi

singbox_loop &

start_watchers

# Cron update proxy tiap 12 jam + rotasi log harian (hormati flag .stopped)
(
  while true; do
    sleep 43200
    [ -f "$PERSIST_DIR/.stopped" ] && continue
    rotate_logs
    fetch_proxies
  done
) &
