#!/system/bin/sh
# action.sh — dump log + service controller (KernelSU action button)
MODDIR=${0%/*}
PERSIST_DIR="/data/adb/mobile_proxy_tailscale"

CONF_FILE="$PERSIST_DIR/config.json"
BIN_DIR="$MODDIR/bin"
RUN_DIR="$PERSIST_DIR/run"
STATE_FILE="$PERSIST_DIR/mobile-proxy-singbox.json"
LOG_DIR="$PERSIST_DIR/logs"
STATE_TAILSCALE="$PERSIST_DIR/tailscaled.state"

cmd="$1"

is_running() {
  if command -v pgrep >/dev/null 2>&1; then
    pgrep -f "$1" >/dev/null 2>&1
  else
    ps 2>/dev/null | grep -q "$1"
  fi
}

kill_pat() {
  if command -v pkill >/dev/null 2>&1; then
    pkill -f "$1" >/dev/null 2>&1 || true
  else
    for p in $(ps -o pid,args 2>/dev/null | grep "$1" | grep -v grep | awk '{print $1}'); do
      kill -9 "$p" 2>/dev/null
    done
  fi
}

do_stop() {
  echo "[*] Stopping sing-box + tailscaled ..."
  touch "$PERSIST_DIR/.stopped" 2>/dev/null || true
  kill_pat "$BIN_DIR/sing-box"
  sleep 2
  kill_pat "$BIN_DIR/tailscaled"
  sleep 2
  if command -v pkill >/dev/null 2>&1; then
    pkill -9 -f "$BIN_DIR/sing-box" 2>/dev/null || true
    pkill -9 -f "$BIN_DIR/tailscaled" 2>/dev/null || true
  fi
  echo "[+] Stopped. (flag .stopped aktif — loop tidak restart)"
}

do_start() {
  echo "[*] Starting service ..."
  rm -f "$PERSIST_DIR/.stopped" 2>/dev/null || true
  # auto-heal corrupt tailscale state (node OS changed)
  if grep -qi "node OS changed" "$LOG_DIR/tailscale_up.log" 2>/dev/null || grep -qi "node OS changed" "$LOG_DIR/tailscaled.log" 2>/dev/null; then
    echo "[!] Deteksi 'node OS changed' -> reset tailscaled.state"
    rm -f "$STATE_TAILSCALE" 2>/dev/null || true
    rm -f "$LOG_DIR/tailscale_up.log" 2>/dev/null || true
  fi
  # single-instance guard
  if command -v pgrep >/dev/null 2>&1 && pgrep -f "$MODDIR/service.sh" >/dev/null 2>&1; then
    echo "[i] service.sh sudah jalan — restart daemon saja"
    kill_pat "$BIN_DIR/sing-box"
    kill_pat "$BIN_DIR/tailscaled"
    sleep 2
  fi
  nohup sh "$MODDIR/service.sh" >/dev/null 2>&1 &
  sleep 4
  if is_running "$BIN_DIR/tailscaled" || is_running "$BIN_DIR/sing-box"; then
    echo "[+] Start triggered."
  else
    echo "[!] Start belum terlihat, cek $LOG_DIR/"
  fi
}

do_reset() {
  echo "[*] RESET tailscale state (fix 'node OS changed') ..."
  touch "$PERSIST_DIR/.stopped" 2>/dev/null || true
  kill_pat "$BIN_DIR/tailscaled"
  kill_pat "$BIN_DIR/sing-box"
  sleep 2
  if command -v pkill >/dev/null 2>&1; then
    pkill -9 -f "$BIN_DIR/tailscaled" 2>/dev/null || true
    pkill -9 -f "$BIN_DIR/sing-box" 2>/dev/null || true
  fi
  rm -f "$STATE_TAILSCALE" 2>/dev/null || true
  rm -f "$LOG_DIR/tailscale_up.log" 2>/dev/null || true
  echo "[*] State dihapus, restart service ..."
  rm -f "$PERSIST_DIR/.stopped" 2>/dev/null || true
  nohup sh "$MODDIR/service.sh" >/dev/null 2>&1 &
  sleep 5
  echo "[+] Reset selesai. Cek 'tailscale status' di log bawah."
}

do_fetch() {
  echo "[*] Fetch mobile-proxy-singbox.json (51KB siap pakai, zero python) ..."
  _tmp="$PERSIST_DIR/mobile-proxy-singbox_tmp.json"
  _dst="$PERSIST_DIR/mobile-proxy-singbox.json"
  mkdir -p "$PERSIST_DIR" 2>/dev/null || true
  rm -f "$_tmp" 2>/dev/null || true
  _URLS="https://raw.githubusercontent.com/rickicode/free-proxy-singbox/main/output/mobile-proxy-singbox.json https://cdn.jsdelivr.net/gh/rickicode/free-proxy-singbox@main/output/mobile-proxy-singbox.json https://gh-proxy.com/https://raw.githubusercontent.com/rickicode/free-proxy-singbox/main/output/mobile-proxy-singbox.json"
  _OK=0
  for _u in $_URLS; do
    [ -z "$_u" ] && continue
    echo "[*] Mencoba $_u ..."
    if command -v curl >/dev/null 2>&1; then
      curl -sL --connect-timeout 15 --max-time 30 "$_u" -o "$_tmp" 2>/dev/null || true
    elif command -v wget >/dev/null 2>&1; then
      wget -q --timeout=30 -O "$_tmp" "$_u" 2>/dev/null || true
    fi
    if [ -s "$_tmp" ]; then
      _sz=$(stat -c%s "$_tmp" 2>/dev/null || wc -c < "$_tmp" 2>/dev/null || echo 0)
      if [ "$_sz" -gt 10240 ] && grep -q '"PROXY-FREE"' "$_tmp" 2>/dev/null && grep -q '"outbounds"' "$_tmp" 2>/dev/null; then
        _OK=1
        echo "[+] Download OK via $_u (${_sz}B)"
        break
      fi
    fi
    rm -f "$_tmp" 2>/dev/null || true
  done

  if [ "$_OK" = "1" ] && [ -s "$_tmp" ]; then
    _cnt=$(grep -c '"server":' "$_tmp" 2>/dev/null || echo 0)
    echo "[i] Terverifikasi: $_cnt proxy entri"
    if [ -f "$_dst" ] && command -v sha1sum >/dev/null 2>&1; then
      _h1=$(sha1sum "$_dst" 2>/dev/null | awk '{print $1}')
      _h2=$(sha1sum "$_tmp" 2>/dev/null | awk '{print $1}')
      if [ "$_h1" = "$_h2" ]; then
        echo "[i] Konten identik (hash sama) — skip restart"
        rm -f "$_tmp" 2>/dev/null || true
        return 0
      fi
    fi
    mv -f "$_tmp" "$_dst"
    _sz=$(stat -c%s "$_dst" 2>/dev/null || wc -c < "$_dst" 2>/dev/null || echo 0)
    echo "[+] mobile-proxy-singbox.json updated ($((_sz/1024))KB)"
    rm -f "$PERSIST_DIR/.stopped" 2>/dev/null || true
    kill_pat "$BIN_DIR/sing-box"
    sleep 2
    # Jika service.sh belum jalan sama sekali, baru spawn
    if ! pgrep -f "$MODDIR/service.sh" >/dev/null 2>&1; then
      echo "[*] service.sh tidak aktif -> spawn service.sh ..."
      nohup sh "$MODDIR/service.sh" >/dev/null 2>&1 &
      sleep 3
    else
      echo "[*] sing-box di-kill — background loop service.sh otomatis regenerate config"
    fi
    echo "[+] Fetch selesai — cek Yacd /proxies"
  else
    echo "[-] Download gagal di semua mirror (cek koneksi internet)"
    rm -f "$_tmp" 2>/dev/null || true
    return 1
  fi
}

do_fix_yacd() {
  echo "[*] Diagnosa Yacd / Clash API ..."
  if ! is_running "$BIN_DIR/sing-box"; then
    echo "[-] sing-box STOPPED -> Yacd pasti error. Jalankan: sh $MODDIR/action.sh start"
    return 0
  fi
  echo "[i] Test http://127.0.0.1:9090/version (secret=singbox)"
  if command -v curl >/dev/null 2>&1; then
    curl -s --max-time 5 -H "Authorization: Bearer singbox" http://127.0.0.1:9090/version 2>&1 | head -n 5
    _c=$?
    if [ $_c -eq 0 ]; then echo "[+] Clash API OK (sing-box 1.13.12)"; else echo "[-] curl gagal code $_c"; fi
  elif command -v wget >/dev/null 2>&1; then
    wget -qO- --header="Authorization: Bearer singbox" http://127.0.0.1:9090/version 2>&1 | head -n 5
  else
    echo "[!] curl/wget tidak ada, pakai: curl -H 'Authorization: Bearer singbox' http://127.0.0.1:9090/version"
  fi
  echo ""
  TS_IP=$("$BIN_DIR/tailscale" --socket="$RUN_DIR/tailscaled.sock" ip -4 2>/dev/null)
  if [ -n "$TS_IP" ]; then
    echo "[+] Tailscale IP: $TS_IP"
    echo "    Lokal  : http://127.0.0.1:9090/ui/?hostname=127.0.0.1&port=9090&secret=singbox"
    echo "    Tailscale: http://$TS_IP:9090/ui/?hostname=$TS_IP&port=9090&secret=singbox"
  else
    echo "[-] Tailscale IP belum ada (node belum login, state corrupt?). Jalankan: sh $MODDIR/action.sh reset"
  fi
  echo ""
  if [ -f "$MODDIR/dashboard/index.html" ]; then
    echo "[+] dashboard/index.html ADA"
  else
    echo "[-] dashboard BELUM ADA -> re-flash zip"
  fi
  echo "[i] Jika Yacd masih '出错了' -> buka URL di Incognito atau Clear site data 127.0.0.1:9090"
}

do_status() {
  echo "==================================="
  echo " Mobile Proxy (Multi-port) status"
  echo "==================================="
  if is_running "$BIN_DIR/tailscaled"; then echo "[+] tailscaled: RUNNING"; else echo "[-] tailscaled: STOPPED"; fi
  if is_running "$BIN_DIR/sing-box"; then echo "[+] sing-box  : RUNNING"; else echo "[-] sing-box  : STOPPED"; fi
  [ -d "$PERSIST_DIR" ] && echo "[i] Persist dir: $PERSIST_DIR (OK)" || echo "[!] Persist dir: MISSING"
  if [ -S "$RUN_DIR/tailscaled.sock" ]; then
    echo "[i] Socket: ACTIVE"
    "$BIN_DIR/tailscale" --socket="$RUN_DIR/tailscaled.sock" status 2>&1 | head -n 12
    TS_IP=$("$BIN_DIR/tailscale" --socket="$RUN_DIR/tailscaled.sock" ip -4 2>/dev/null)
    [ -n "$TS_IP" ] && echo "[i] TS IP: $TS_IP  -> http://$TS_IP:9090/ui/?hostname=$TS_IP&port=9090&secret=singbox"
  else
    echo "[!] Socket: MISSING"
  fi
  echo "==================================="
}

case "$cmd" in
  stop) do_stop; do_status; exit 0 ;;
  start) do_start; do_status; exit 0 ;;
  restart) do_stop; sleep 2; do_start; do_status; exit 0 ;;
  reset) do_reset; do_status; exit 0 ;;
  fetch) do_fetch; exit 0 ;;
  fix-yacd) do_fix_yacd; exit 0 ;;
  toggle)
    if is_running "$BIN_DIR/sing-box" || is_running "$BIN_DIR/tailscaled"; then
      do_stop
    else
      do_start
    fi
    do_status
    exit 0
    ;;
  status) do_status; exit 0 ;;
  "") ;; # lanjut dump log default
  *) echo "usage: $0 [start|stop|restart|reset|fetch|fix-yacd|toggle|status]"; exit 1 ;;
esac

echo "==================================="
echo " Mobile Proxy (Multi-port) logs"
echo "==================================="

if is_running "$BIN_DIR/tailscaled"; then
  echo "[+] tailscaled: RUNNING"
else
  echo "[-] tailscaled: STOPPED"
fi

if is_running "$BIN_DIR/sing-box"; then
  echo "[+] sing-box  : RUNNING"
else
  echo "[-] sing-box  : STOPPED"
fi

if [ -d "$PERSIST_DIR" ]; then
  echo "[i] Persist dir: $PERSIST_DIR (OK)"
else
  echo "[!] Persist dir: MISSING (re-flash zip v3.0.5)"
fi

echo "-----------------------------------"

if [ -S "$RUN_DIR/tailscaled.sock" ]; then
  echo "[i] Tailscale Socket: ACTIVE"
  echo "[*] Tailscale Status Output:"
  "$BIN_DIR/tailscale" --socket="$RUN_DIR/tailscaled.sock" status 2>&1 | head -n 10

  TS_IP=$("$BIN_DIR/tailscale" --socket="$RUN_DIR/tailscaled.sock" ip -4 2>/dev/null)
  if [ -n "$TS_IP" ]; then
     echo "-----------------------------------"
     echo "[+] Yacd Lokal (di HP, via browser HP):"
     echo "    http://127.0.0.1:9090/ui/?hostname=127.0.0.1&port=9090&secret=singbox"
     echo "[+] Yacd via Tailscale (dari PC satu tailnet):"
     echo "    http://$TS_IP:9090/ui/?hostname=$TS_IP&port=9090&secret=singbox"
     echo "[+] Yacd publik (fallback, butuh internet):"
     echo "    http://yacd.metacubex.one/?hostname=$TS_IP&port=9090&secret=singbox"
  fi
else
  echo "[!] Tailscale Socket: MISSING"
fi

echo "-----------------------------------"

if [ -f "$LOG_DIR/tailscaled.log" ]; then
  echo "[*] Tailscaled Log (Last 5 lines):"
  tail -n 5 "$LOG_DIR/tailscaled.log"
fi

echo ""

if [ -f "$LOG_DIR/tailscale_up.log" ]; then
  echo "[*] Tailscale Up Log (Last 5 lines):"
  tail -n 5 "$LOG_DIR/tailscale_up.log"
fi

echo ""

if [ -f "$LOG_DIR/singbox_run.log" ]; then
  echo "[*] Sing-box Log (Last 5 lines):"
  tail -n 5 "$LOG_DIR/singbox_run.log"
fi

echo "-----------------------------------"
if [ -f "$STATE_FILE" ]; then
  echo "[+] Config mobile proxy: Terdeteksi ($(grep -c '"server":' "$STATE_FILE" 2>/dev/null || echo "0") proxy entri)"
else
  echo "[-] Config mobile proxy: Belum ada"
fi
if [ -f "$MODDIR/dashboard/index.html" ]; then
  echo "[+] Yacd local dashboard: ADA ($MODDIR/dashboard/)"
else
  echo "[-] Yacd local dashboard: BELUM ADA (re-flash zip terbaru)"
fi
echo "==================================="
echo "[i] Commands: start|stop|restart|reset|fetch|fix-yacd|toggle|status"
echo "[i] Fetch proxy manual: sh $MODDIR/action.sh fetch"
echo "[i] Reset state corrupt: sh $MODDIR/action.sh reset"
