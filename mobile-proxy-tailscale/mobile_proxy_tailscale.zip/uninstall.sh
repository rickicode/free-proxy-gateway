#!/system/bin/sh
# Hapus runtime & biner saat uninstall, tapi PERTAHANKAN config.json
PERSIST_DIR="/data/adb/mobile_proxy_tailscale"
rm -rf "$PERSIST_DIR/bin" "$PERSIST_DIR/run" "$PERSIST_DIR/logs" "$PERSIST_DIR/tmp" 2>/dev/null || true
rm -f "$PERSIST_DIR/tailscaled.state" "$PERSIST_DIR/live-proxies.json" "$PERSIST_DIR/yacd_cache.zip" "$PERSIST_DIR/.stopped" 2>/dev/null || true
# Bersihkan symlink lama & service queue
rm -rf /data/adb/modules/mobile_proxy_tailscale/run 2>/dev/null || true
rm -f /data/adb/service.d/mproxy_service.sh 2>/dev/null || true
